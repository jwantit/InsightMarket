package com.InsightMarket.domain.brand;

public enum BrandRole {
    BRAND_ADMIN, MARKETER
}
