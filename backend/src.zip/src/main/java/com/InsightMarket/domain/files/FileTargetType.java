package com.InsightMarket.domain.files;

public enum FileTargetType {
    BOARD, COMMENT, SOLUTION
}
