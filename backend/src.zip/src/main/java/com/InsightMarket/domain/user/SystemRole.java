package com.InsightMarket.domain.user;

public enum SystemRole {
    ADMIN, COMPANY_ADMIN, USER
}
