package com.InsightMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsightMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
